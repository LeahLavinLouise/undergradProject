#!/usr/bin/env python
# coding: utf-8

# In[5]:


import streamlit as st
st.markdown('<link href="AppStyling.css" rel="stylesheet">', unsafe_allow_html=True)
import joblib
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import CountVectorizer

# Download NLTK resources (stopwords and lemmatizer)
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('omw-1.4')
nltk.download('wordnet')

# Load the trained model
model = joblib.load('depression_classifier.pkl')
vectorizer = joblib.load('vectorizer.pkl')

# Define stopwords and lemmatizer
stopwords = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

def main():
    st.title("Depression Classifier")
    st.write("Enter the text to classify depression:")
    
    # Add text input field
    user_text = st.text_area("Enter your text here", "")
    
    # Preprocess the input text
    preprocessed_text = preprocess_text(user_text)
    
    # Vectorize the preprocessed text
    vectorized_text = vectorizer.transform([preprocessed_text])
      
       # Make predictions using the loaded model
    prediction = model.predict(vectorized_text)

    # Display the prediction result
    if prediction[0] == 1:
        st.write("Prediction: Depressed")
    else:
        st.write("Prediction: Not Depressed")
        
def preprocess_text(text):
    # Convert to lowercase
    text = text.lower()
    
    # Tokenize the text
    tokens = word_tokenize(text)
    
    # Remove stopwords and punctuation
    tokens = [token for token in tokens if token not in stopwords and token.isalnum()]
    
    # Lemmatize the tokens
    tokens = [lemmatizer.lemmatize(token) for token in tokens]
    
    # Join the tokens back into a single string
    preprocessed_text = ' '.join(tokens)
    
    # Return the preprocessed text
    return preprocessed_text

if __name__ == '__main__':
    main()


# In[ ]:





# In[ ]:




